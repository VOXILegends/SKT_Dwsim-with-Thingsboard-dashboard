import time
import threading
import traceback
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import subprocess

import customtkinter as ctk
from tkinter import filedialog, messagebox

from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
import requests
import xml.etree.ElementTree as ET

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure


# ========================= DEFAULTS =========================
DEFAULTS = {
    # ---- Influx (read) ----
    "influx_url": "https://us-east-1-1.aws.cloud2.influxdata.com",
    "influx_org": "skt",
    "influx_bucket": "skt1",
    "influx_token": "",
    "measurement": "sht20",
    "device_tag": "roman",
    "range_minutes": 30,
    "refresh_secs": 5,

    # ---- Influx (write back) ----
    "out_measurement": "dwsim_outputs",  # measurement tujuan 4 parameter

    # ---- DWSIM ----
    "inlet_key": "Cold Water Inlet",
    "out_keys": ("Cold Water Outlet", "Hot Water Inlet", "Hot Water Outlet"),
    "consolehost": r"C:\Program Files\DWSIM\DWSIM.ConsoleHost.exe",
    "solve_timeout_sec": 60,
}


# ========================= Influx helpers =========================
def influx_health(url: str) -> str:
    r = requests.get(url.rstrip("/") + "/health", timeout=15)
    r.raise_for_status()
    return r.text


def _query_with_retry(client: InfluxDBClient, flux: str, tries: int = 4):
    last = None
    for i in range(tries):
        try:
            return client.query_api().query_data_frame(flux)
        except Exception as e:
            last = e
            time.sleep(1.5 * (i + 1))
    raise last


def get_latest_temperature_c(
    url: str,
    token: str,
    org: str,
    bucket: str,
    measurement: str,
    device_tag: str,
    range_minutes: int = 30,
) -> Optional[float]:
    flux = f'''
    from(bucket: "{bucket}")
      |> range(start: -{int(range_minutes)}m)
      |> filter(fn: (r) => r["_measurement"] == "{measurement}")
      |> filter(fn: (r) => r["device"] == "{device_tag}")
      |> filter(fn: (r) => r["_field"] == "temperature_c")
      |> keep(columns: ["_time","_value"])
      |> last()
    '''
    with InfluxDBClient(url=url, token=token, org=org, timeout=20000) as client:
        df = _query_with_retry(client, flux, tries=4)
    if isinstance(df, list) and len(df):
        df = df[0]
    if df is None or df.empty:
        return None
    try:
        return float(df["_value"].iloc[-1])
    except Exception:
        return None


def safe_float(x) -> Optional[float]:
    try:
        v = float(x)
        if v != v:  # NaN
            return None
        return v
    except Exception:
        return None


def write_four_params_to_influx_sync(
    url: str,
    token: str,
    org: str,
    bucket: str,
    measurement: str,
    device_tag: str,
    flowsheet_path: str,
    inlet_c: Optional[float],
    cold_out_c: Optional[float],
    hot_in_c: Optional[float],
    hot_out_c: Optional[float],
):
    """
    Tulis 4 parameter sebagai 4 point TERPISAH (SYNCHRONOUS).
    Field names:
      - cold_water_inlet_c
      - cold_water_outlet_c
      - hot_water_inlet_c
      - hot_water_outlet_c
    """
    fs_name = Path(flowsheet_path).stem

    rows: List[Point] = []
    def add(field_name: str, value: Optional[float]):
        val = safe_float(value)
        if val is None:
            return
        p = (
            Point(measurement)
            .tag("device", device_tag)
            .tag("flowsheet", fs_name)
            .field(field_name, val)
        )
        rows.append(p)

    add("cold_water_inlet_c", inlet_c)
    add("cold_water_outlet_c", cold_out_c)
    add("hot_water_inlet_c", hot_in_c)
    add("hot_water_outlet_c", hot_out_c)

    if not rows:
        return 0

    with InfluxDBClient(url=url, token=token, org=org, timeout=20000) as client:
        wa = client.write_api(write_options=SYNCHRONOUS)  # langsung commit
        wa.write(bucket=bucket, org=org, record=rows)
        # SYNCHRONOUS: tidak perlu flush/close manual
    return len(rows)


# ========================= DWSIM XML helpers =========================
def open_flowsheet_xml(path: str) -> ET.ElementTree:
    p = Path(path)
    if p.suffix.lower() != ".xml":
        raise ValueError("Gunakan file .xml (bukan .dwxmz).")
    return ET.parse(p)


def save_flowsheet_xml(tree: ET.ElementTree, path: str):
    tree.write(path, encoding="utf-8", xml_declaration=True)


def build_stream_index(root: ET.Element) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, ET.Element]]:
    id_to_tag: Dict[str, str] = {}
    tag_to_id: Dict[str, str] = {}
    for go in root.findall(".//GraphicObject[ObjectType='MaterialStream']"):
        id_el = go.find("Name"); tag_el = go.find("Tag")
        sid = (id_el.text or "").strip() if id_el is not None else ""
        tag = (tag_el.text or "").strip() if tag_el is not None else ""
        if sid and tag:
            id_to_tag[sid] = tag
            tag_to_id[tag] = sid

    id_to_sim: Dict[str, ET.Element] = {}
    for so in root.findall(".//SimulationObject[Type='DWSIM.Thermodynamics.Streams.MaterialStream']"):
        name_el = so.find("Name")
        sid = (name_el.text or "").strip() if name_el is not None else ""
        if sid:
            id_to_sim[sid] = so

    return id_to_tag, tag_to_id, id_to_sim


def list_streams_display(path: str) -> List[str]:
    tree = open_flowsheet_xml(path)
    root = tree.getroot()
    id_to_tag, _, _ = build_stream_index(root)
    nice = [f"{tag} ({sid})" for sid, tag in id_to_tag.items()]
    nice.sort()
    return nice


def resolve_key_to_id(root: ET.Element, key: str) -> Optional[str]:
    id_to_tag, tag_to_id, _ = build_stream_index(root)
    k = (key or "").strip()
    if not k:
        return None
    if k in tag_to_id:
        return tag_to_id[k]
    if k in id_to_tag:
        return k
    for tag in tag_to_id:
        if k.lower() in tag.lower():
            return tag_to_id[tag]
    for sid in id_to_tag:
        if k.lower() in sid.lower():
            return sid
    return None


def get_stream_temperature_c_by_node(sim_node: Optional[ET.Element]) -> Optional[float]:
    if sim_node is None:
        return None
    temp_el = sim_node.find(".//Phase[ComponentName='Mixture']/Properties/temperature")
    if temp_el is not None and (temp_el.text or "").strip():
        try:
            return float(temp_el.text) - 273.15
        except Exception:
            return None
    return None


def set_stream_temperature_c_by_node(sim_node: ET.Element, temp_c: float) -> bool:
    temp_el = sim_node.find(".//Phase[ComponentName='Mixture']/Properties/temperature")
    if temp_el is not None:
        temp_el.text = f"{float(temp_c) + 273.15:.6f}"  # Kelvin
        return True
    return False


def write_inlet_temperature(path: str, inlet_key: str, temp_c: float):
    tree = open_flowsheet_xml(path)
    root = tree.getroot()
    _, _, id_to_sim = build_stream_index(root)
    sid = resolve_key_to_id(root, inlet_key)
    if not sid:
        raise ValueError(f"Stream '{inlet_key}' tidak ditemukan (pakai List Streams + Gunakan pilihan).")
    node = id_to_sim.get(sid)
    if not node:
        raise ValueError(f"SimulationObject untuk ID '{sid}' tidak ditemukan.")
    if not set_stream_temperature_c_by_node(node, temp_c):
        raise RuntimeError("Gagal set temperature (cek skema XML).")
    save_flowsheet_xml(tree, path)


def read_outputs(path: str, keys: List[str]) -> Dict[str, Optional[float]]:
    tree = open_flowsheet_xml(path)
    root = tree.getroot()
    _, _, id_to_sim = build_stream_index(root)
    out: Dict[str, Optional[float]] = {}
    for key in keys:
        sid = resolve_key_to_id(root, key)
        node = id_to_sim.get(sid) if sid else None
        out[key] = get_stream_temperature_c_by_node(node)
    return out


# ========================= DWSIM ConsoleHost (opsional) =========================
def solve_with_consolehost(consolehost_path: str, input_xml: str, timeout_sec: int = 60) -> str:
    exe = Path(consolehost_path)
    if not exe.exists():
        raise FileNotFoundError(f"ConsoleHost tidak ditemukan: {consolehost_path}")
    # format umum
    args = f'"{exe}" -solve -input "{input_xml}" -output "{input_xml}"'
    proc = subprocess.run(args, shell=True, capture_output=True, text=True, timeout=timeout_sec)
    if proc.returncode != 0:
        raise RuntimeError(f"ConsoleHost exit {proc.returncode}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}")
    return proc.stdout or ""


# ========================= UI =========================
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title("Influx → DWSIM XML (Auto Solve & Push 4 Params)")
        self.geometry("1220x780")
        self.minsize(1060, 680)

        # timeseries buffers
        self.series_influx: List[float] = []
        self.series_inlet_written: List[float] = []
        self.series_out_cold: List[Optional[float]] = []
        self.series_out_hot_in: List[Optional[float]] = []
        self.series_out_hot_out: List[Optional[float]] = []

        self._auto = False

        self._build_sidebar()
        self._build_main()
        self._apply_defaults()

    # ---------- Build UI ----------
    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=380, corner_radius=0)
        sb.pack(side="left", fill="y")
        self.sidebar = sb

        ctk.CTkLabel(sb, text="Settings", font=("Segoe UI", 18, "bold")).pack(pady=(16, 8))

        # Influx (read)
        self.influx_url = ctk.CTkEntry(sb, placeholder_text="Influx URL")
        self.influx_org = ctk.CTkEntry(sb, placeholder_text="Influx Org/OrgID")
        self.influx_bucket = ctk.CTkEntry(sb, placeholder_text="Influx Bucket")
        self.influx_token = ctk.CTkEntry(sb, placeholder_text="Influx Token", show="•")
        self.measurement = ctk.CTkEntry(sb, placeholder_text="Measurement (mis. sht20)")
        self.device_tag = ctk.CTkEntry(sb, placeholder_text="Device tag (mis. roman)")
        for w in [self.influx_url, self.influx_org, self.influx_bucket, self.influx_token, self.measurement, self.device_tag]:
            w.pack(padx=12, pady=6, fill="x")

        # Influx (write back)
        ctk.CTkLabel(sb, text="Out measurement (4 params → Influx)", anchor="w").pack(padx=12, pady=(6, 0), fill="x")
        self.out_measurement = ctk.CTkEntry(sb, placeholder_text="dwsim_outputs")
        self.out_measurement.pack(padx=12, pady=(4, 6), fill="x")
        self.push_enabled = ctk.BooleanVar(value=True)
        self.chk_push = ctk.CTkCheckBox(sb, text="Write 4 params to Influx", variable=self.push_enabled)
        self.chk_push.pack(padx=12, pady=(0, 8), anchor="w")

        # Flow file
        ctk.CTkLabel(sb, text="Flowsheet (.xml)", anchor="w").pack(padx=12, pady=(6, 0), fill="x")
        row = ctk.CTkFrame(sb); row.pack(padx=12, pady=(4, 6), fill="x")
        self.flowsheet = ctk.CTkEntry(row, placeholder_text=r"C:\...\flowsheet.xml")
        self.flowsheet.pack(side="left", expand=True, fill="x")
        ctk.CTkButton(row, text="Browse", width=84, command=self._browse_xml).pack(side="left", padx=(6, 0))

        # inlet key
        self.inlet_key = ctk.CTkEntry(sb, placeholder_text="Cold Water Inlet (Tag atau ID)")
        self.inlet_key.pack(padx=12, pady=(4, 8), fill="x")

        # ConsoleHost (opsional)
        ctk.CTkLabel(sb, text="DWSIM ConsoleHost.exe (opsional)", anchor="w").pack(padx=12, pady=(6, 0), fill="x")
        rowc = ctk.CTkCTkFrame = ctk.CTkFrame(sb); rowc.pack(padx=12, pady=(4, 6), fill="x")
        self.consolehost = ctk.CTkEntry(rowc, placeholder_text=r"C:\Program Files\DWSIM\DWSIM.ConsoleHost.exe")
        self.consolehost.pack(side="left", expand=True, fill="x")
        ctk.CTkButton(rowc, text="Browse", width=84, command=self._browse_consolehost).pack(side="left", padx=(6, 0))
        self.solve_enabled = ctk.BooleanVar(value=False)
        self.chk_solve = ctk.CTkCheckBox(sb, text="Solve with ConsoleHost", variable=self.solve_enabled)
        self.chk_solve.pack(padx=12, pady=(0, 8), anchor="w")

        # helper buttons
        self.btn_health = ctk.CTkButton(sb, text="Health Check", command=self._on_health)
        self.btn_health.pack(padx=12, pady=(4, 6), fill="x")

        self.btn_streams = ctk.CTkButton(sb, text="List Streams", command=self._on_list_streams)
        self.btn_streams.pack(padx=12, pady=6, fill="x")

        ctk.CTkLabel(sb, text="Pilih stream dari daftar:", anchor="w").pack(padx=12, pady=(6, 0), fill="x")
        self.stream_options = ctk.CTkComboBox(sb, values=[], state="readonly")
        self.stream_options.pack(padx=12, pady=(4, 6), fill="x")
        ctk.CTkButton(sb, text="Gunakan pilihan", command=self._use_selected_stream).pack(padx=12, pady=(0, 8), fill="x")

        # actions
        self.btn_test = ctk.CTkButton(sb, text="Test Influx (read)", command=self._on_test_influx)
        self.btn_write = ctk.CTkButton(sb, text="Write + (Solve) + Reload + Push", command=self._on_write_solve_reload, fg_color="#22c55e", hover_color="#16a34a")
        self.btn_test.pack(padx=12, pady=6, fill="x")
        self.btn_write.pack(padx=12, pady=(6, 6), fill="x")

        # auto section
        row2 = ctk.CTkFrame(sb); row2.pack(padx=12, pady=(4, 6), fill="x")
        ctk.CTkLabel(row2, text="Auto refresh (s)").pack(side="left")
        self.refresh_secs_var = ctk.IntVar(value=DEFAULTS["refresh_secs"])
        self.refresh_secs = ctk.CTkEntry(row2, width=72, textvariable=self.refresh_secs_var)
        self.refresh_secs.pack(side="right")

        self.auto_write_var = ctk.BooleanVar(value=True)
        self.chk_auto_write = ctk.CTkCheckBox(sb, text="Auto: Write → (Solve) → Reload → Push", variable=self.auto_write_var)
        self.chk_auto_write.pack(padx=12, pady=(0, 6), anchor="w")

        self.btn_auto = ctk.CTkButton(sb, text="Start Auto", command=self._on_toggle_auto)
        self.btn_auto.pack(padx=12, pady=(2, 10), fill="x")

        # status
        self.progress = ctk.CTkProgressBar(sb)
        self.progress.set(0)
        self.progress.pack(padx=12, pady=(4, 6), fill="x")
        self.status = ctk.CTkLabel(sb, text="", anchor="w", justify="left", wraplength=340)
        self.status.pack(padx=12, pady=(2, 8), fill="x")

    def _build_main(self):
        main = ctk.CTkFrame(self); main.pack(side="left", fill="both", expand=True)
        self.main = main

        # KPI cards
        cards = ctk.CTkFrame(main); cards.pack(fill="x", padx=12, pady=12)

        self.latest_influx_var = ctk.StringVar(value="-")
        self.written_var = ctk.StringVar(value="-")
        self.out_cold_var = ctk.StringVar(value="-")
        self.out_hot_in_var = ctk.StringVar(value="-")
        self.out_hot_out_var = ctk.StringVar(value="-")

        self._card(cards, "Influx Temp (°C)", self.latest_influx_var).pack(side="left", expand=True, fill="x", padx=6)
        self._card(cards, "Inlet Written (°C)", self.written_var).pack(side="left", expand=True, fill="x", padx=6)
        self._card(cards, "Cold Water Outlet (°C)", self.out_cold_var).pack(side="left", expand=True, fill="x", padx=6)
        self._card(cards, "Hot Water Inlet (°C)", self.out_hot_in_var).pack(side="left", expand=True, fill="x", padx=6)
        self._card(cards, "Hot Water Outlet (°C)", self.out_hot_out_var).pack(side="left", expand=True, fill="x", padx=6)

        # Figure
        self.fig = Figure(figsize=(8.3, 4.5), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title("Influx vs XML (after Solve)")
        self.ax.set_xlabel("Sample #")
        self.ax.set_ylabel("°C")
        self.canvas = FigureCanvasTkAgg(self.fig, master=main)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=12, pady=(0, 12))

        # console
        self.console = ctk.CTkTextbox(main, height=220)
        self.console.pack(fill="both", expand=False, padx=12, pady=(0, 12))
        self._log("Ready.")

    def _card(self, parent, title, var):
        f = ctk.CTkFrame(parent)
        ctk.CTkLabel(f, text=title, font=("Segoe UI", 12)).pack(pady=(10, 0))
        ctk.CTkLabel(f, textvariable=var, font=("Segoe UI", 24, "bold")).pack(pady=(4, 12))
        return f

    def _apply_defaults(self):
        self.influx_url.insert(0, DEFAULTS["influx_url"])
        self.influx_org.insert(0, DEFAULTS["influx_org"])
        self.influx_bucket.insert(0, DEFAULTS["influx_bucket"])
        self.measurement.insert(0, DEFAULTS["measurement"])
        self.device_tag.insert(0, DEFAULTS["device_tag"])
        self.inlet_key.insert(0, DEFAULTS["inlet_key"])
        self.consolehost.insert(0, DEFAULTS["consolehost"])
        self.out_measurement.insert(0, DEFAULTS["out_measurement"])

    # ---------- helpers ----------
    def _browse_xml(self):
        fn = filedialog.askopenfilename(
            title="Pilih DWSIM XML",
            filetypes=[("DWSIM XML", "*.xml"), ("All files", "*.*")]
        )
        if fn:
            self.flowsheet.delete(0, "end")
            self.flowsheet.insert(0, fn)

    def _browse_consolehost(self):
        fn = filedialog.askopenfilename(
            title="Pilih DWSIM.ConsoleHost.exe",
            filetypes=[("ConsoleHost", "*.exe"), ("All files", "*.*")]
        )
        if fn:
            self.consolehost.delete(0, "end")
            self.consolehost.insert(0, fn)

    def _set_status(self, text, p=None):
        self.status.configure(text=text)
        if p is not None:
            try: self.progress.set(p)
            except Exception: pass

    def _log(self, text):
        self.console.configure(state="normal")
        self.console.insert("end", text + "\n")
        self.console.see("end")
        self.console.configure(state="disabled")

    def _append_point(self, influx: Optional[float], written: Optional[float],
                      out_cold: Optional[float], out_hot_in: Optional[float], out_hot_out: Optional[float]):
        def to_val(x): return float('nan') if x is None else float(x)
        self.series_influx.append(to_val(influx))
        self.series_inlet_written.append(to_val(written))
        self.series_out_cold.append(out_cold if out_cold is not None else None)
        self.series_out_hot_in.append(out_hot_in if out_hot_in is not None else None)
        self.series_out_hot_out.append(out_hot_out if out_hot_out is not None else None)

    def _plot(self):
        self.ax.clear()
        self.ax.set_title("Influx vs XML (after Solve)")
        self.ax.set_xlabel("Sample #"); self.ax.set_ylabel("°C")
        n = len(self.series_influx)
        x = list(range(1, n + 1))
        if n > 0:
            self.ax.plot(x, self.series_influx, label="Influx temperature")
            self.ax.plot(x, self.series_inlet_written, label="Inlet written (XML)")
            if any(v is not None for v in self.series_out_cold):
                y = [float('nan') if v is None else v for v in self.series_out_cold]
                self.ax.plot(x, y, label="Cold Water Outlet")
            if any(v is not None for v in self.series_out_hot_in):
                y = [float('nan') if v is None else v for v in self.series_out_hot_in]
                self.ax.plot(x, y, label="Hot Water Inlet")
            if any(v is not None for v in self.series_out_hot_out):
                y = [float('nan') if v is None else v for v in self.series_out_hot_out]
                self.ax.plot(x, y, label="Hot Water Outlet")
            self.ax.legend()
        self.canvas.draw_idle()

    # ---------- actions ----------
    def _on_health(self):
        try:
            text = influx_health(self.influx_url.get().strip())
            self._log("[Health] " + text)
            self._set_status("Influx /health OK", 1.0)
        except Exception as e:
            self._set_status(f"/health error: {e}")
            self._log("ERROR: " + str(e))

    def _on_list_streams(self):
        p = self.flowsheet.get().strip()
        if not Path(p).exists():
            messagebox.showerror("Error", "Flowsheet XML tidak ditemukan.")
            return
        try:
            names = list_streams_display(p)
            if names:
                self._log("[Streams]\n- " + "\n- ".join(names))
                self._set_status(f"{len(names)} material streams ditemukan.")
                self.stream_options.configure(values=names)
                self.stream_options.set(names[0])
            else:
                self._log("[Streams] (kosong)")
        except Exception as e:
            self._set_status(f"Gagal list streams: {e}")
            self._log("ERROR: " + str(e))

    def _use_selected_stream(self):
        val = self.stream_options.get().strip()
        if val:
            key = val.split(" (", 1)[0] if val.endswith(")") and " (" in val else val
            self.inlet_key.delete(0, "end")
            self.inlet_key.insert(0, key)
            self._log(f"[UI] Inlet set to: {key}")

    def _on_test_influx(self):
        try:
            t = get_latest_temperature_c(
                url=self.influx_url.get().strip(),
                token=self.influx_token.get().strip(),
                org=self.influx_org.get().strip(),
                bucket=self.influx_bucket.get().strip(),
                measurement=self.measurement.get().strip(),
                device_tag=self.device_tag.get().strip(),
                range_minutes=DEFAULTS["range_minutes"]
            )
            if t is None:
                raise RuntimeError("Tidak ada sample temperature_c")
            self.latest_influx_var.set(f"{t:.2f}")
            self._log(f"[Influx] latest temperature_c = {t:.2f} °C")
            self._set_status("Influx OK", 1.0)
        except Exception as e:
            self._set_status(f"Influx error: {e}")
            self._log("ERROR: " + "".join(traceback.format_exception_only(type(e), e)).strip())

    def _write_solve_reload_once(self) -> Optional[float]:
        """1 siklus: get influx → write XML → (optional) solve → reload outputs → push → plot"""
        xml = self.flowsheet.get().strip()
        if not Path(xml).exists():
            raise FileNotFoundError("Flowsheet XML tidak ditemukan.")

        # 1) ambil dari influx (inlet)
        t = get_latest_temperature_c(
            url=self.influx_url.get().strip(),
            token=self.influx_token.get().strip(),
            org=self.influx_org.get().strip(),
            bucket=self.influx_bucket.get().strip(),
            measurement=self.measurement.get().strip(),
            device_tag=self.device_tag.get().strip(),
            range_minutes=DEFAULTS["range_minutes"]
        )
        if t is None:
            raise RuntimeError("Tidak ada sample temperature_c")

        # 2) write inlet ke XML
        write_inlet_temperature(xml, self.inlet_key.get().strip() or DEFAULTS["inlet_key"], t)
        self.latest_influx_var.set(f"{t:.2f}")
        self.written_var.set(f"{t:.2f}")
        self._log(f"[XML] Wrote inlet '{self.inlet_key.get().strip()}' = {t:.2f} °C")

        # 3) (opsional) solve
        if self.solve_enabled.get():
            ch = self.consolehost.get().strip()
            out = solve_with_consolehost(ch, xml, timeout_sec=DEFAULTS["solve_timeout_sec"])
            self._log("[ConsoleHost] " + (out.strip() or "Solve done."))

        # 4) reload outputs
        outs = read_outputs(xml, list(DEFAULTS["out_keys"]))
        c_out = outs.get("Cold Water Outlet")
        h_in = outs.get("Hot Water Inlet")
        h_out = outs.get("Hot Water Outlet")

        self.out_cold_var.set(self._fmt(c_out))
        self.out_hot_in_var.set(self._fmt(h_in))
        self.out_hot_out_var.set(self._fmt(h_out))

        # 5) push 4 params ke Influx (opsional)
        if self.push_enabled.get():
            n = write_four_params_to_influx_sync(
                url=self.influx_url.get().strip(),
                token=self.influx_token.get().strip(),
                org=self.influx_org.get().strip(),
                bucket=self.influx_bucket.get().strip(),
                measurement=self.out_measurement.get().strip() or DEFAULTS["out_measurement"],
                device_tag=self.device_tag.get().strip(),
                flowsheet_path=xml,
                inlet_c=t,
                cold_out_c=c_out,
                hot_in_c=h_in,
                hot_out_c=h_out,
            )
            self._log(f"[Influx] pushed {n} point(s) to measurement '{self.out_measurement.get().strip() or DEFAULTS['out_measurement']}'")

        # 6) append point & plot
        self._append_point(t, t, c_out, h_in, h_out)
        self._plot()
        return t

    def _on_write_solve_reload(self):
        try:
            self._write_solve_reload_once()
            self._set_status("Write → (Solve) → Reload → Push OK", 1.0)
        except Exception as e:
            self._set_status(f"Error: {e}")
            self._log("ERROR: " + "".join(traceback.format_exception_only(type(e), e)).strip())

    def _on_toggle_auto(self):
        if self._auto:
            self._auto = False
            self.btn_auto.configure(text="Start Auto")
            self._set_status("Auto stopped")
            return

        try:
            secs = max(2, int(self.refresh_secs_var.get()))
        except Exception:
            secs = DEFAULTS["refresh_secs"]
        self._auto = True
        self.btn_auto.configure(text="Stop Auto")
        self._set_status(f"Auto started ({secs}s)")

        def loop():
            while self._auto:
                start = time.time()
                try:
                    if self.auto_write_var.get():
                        self._write_solve_reload_once()
                    else:
                        t = get_latest_temperature_c(
                            url=self.influx_url.get().strip(),
                            token=self.influx_token.get().strip(),
                            org=self.influx_org.get().strip(),
                            bucket=self.influx_bucket.get().strip(),
                            measurement=self.measurement.get().strip(),
                            device_tag=self.device_tag.get().strip(),
                            range_minutes=DEFAULTS["range_minutes"]
                        )
                        self.latest_influx_var.set(self._fmt(t))
                        self._append_point(t, None, None, None, None)
                        self._plot()
                    self._set_status("Auto tick OK")
                except Exception as e:
                    self._set_status(f"Auto error: {e}")
                    self._log("AUTO ERROR: " + "".join(traceback.format_exception_only(type(e), e)).strip())

                try:
                    secs = max(2, int(self.refresh_secs_var.get()))
                except Exception:
                    secs = DEFAULTS["refresh_secs"]
                time.sleep(max(0, secs - (time.time() - start)))

        threading.Thread(target=loop, daemon=True).start()

    # utils
    def _fmt(self, v):
        try:
            return f"{float(v):.2f}"
        except Exception:
            return "-"


if __name__ == "__main__":
    app = App()
    app.mainloop()
